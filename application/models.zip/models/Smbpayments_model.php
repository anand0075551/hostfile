<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Smbpayments_model extends CI_Model {

    public function all_sales_ListCount(){
		
		$user_info 	 = $this->session->userdata('logged_user');
        $user_id 	 = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
		$rolename    = singleDbTableRow($user_id)->rolename;
		$email   	 = singleDbTableRow($user_id)->email;
		
		
			$query = $this->db->count_all_results('smb_sale');
		
        return $query;
    }
		
    public function sale_List($limit = 0, $start = 0)
	{		
		$search = $this->input->get('search');	
		$searchValue = $search['value'];

		$searchByID = '';				
		$user_info 	 = $this->session->userdata('logged_user');
        $user_id 	 = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
		$rolename    = singleDbTableRow($user_id)->rolename;
		$email   	 = singleDbTableRow($user_id)->email;
		
		
		if($searchValue != '')																							
			{																												
				$table_name = "smb_sale";	
				$where_array = array('sale_code' => $searchValue );					
				  $query = $this->db->order_by('id', 'desc')->limit($limit, $start)->where($where_array )->get($table_name); 	
			}											
			else{										
				$query = $this->db->order_by('id', 'desc')->limit($limit, $start)->get('smb_sale');
			}
		
		
		
        return $query;
    }
	public function search_sales_ListCount(){
		
		$user_info 	 = $this->session->userdata('logged_user');
        $user_id 	 = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
		$rolename    = singleDbTableRow($user_id)->rolename;
		$email   	 = singleDbTableRow($user_id)->email;
		
		
			$query = $this->db->count_all_results('smb_sale');
		
        return $query;
    }
		
    public function search_sale_List($limit = 0, $start = 0)
	{		
		$search = $this->input->get('search');	
		$searchValue = $search['value'];

		$searchByID = '';				
		$user_info 	 = $this->session->userdata('logged_user');
        $user_id 	 = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
		$rolename    = singleDbTableRow($user_id)->rolename;
		$email   	 = singleDbTableRow($user_id)->email;
		
		
		if($searchValue != '')																							
			{																												
				$table_name = "smb_sale";	
				$where_array = array('sale_code' => $searchValue );					
				  $query = $this->db->order_by('id', 'desc')->limit($limit, $start)->where($where_array )->get($table_name); 	
			}											
			else{										
				$query = $this->db->order_by('id', 'desc')->limit($limit, $start)->get('smb_sale');
			}
		
		
		
        return $query;
    }


//Stock Report-------------------

//Counting 
	 public function stock_listcount(){
		$user_info = $this->session->userdata('logged_user');
		$user_id = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
		
			$total = $this->db->group_by('product')->get('smb_stock');
			$query = $total->num_rows();
		
        return $query;
    }
	
//Listing
    public function stock_list($limit = 0, $start = 0)
	{		
		$user_info = $this->session->userdata('logged_user');
		$user_id = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
					
				
	if($currentUser == 'admin'){
		$query = $this->db->order_by('id', 'desc')->group_by('product')->group_by('added_by')->limit($limit, $start)->get('smb_stock');
	}
	else{
		$query = $this->db->order_by('id', 'desc')->group_by('product')->group_by('added_by')->limit($limit, $start)->get_where('smb_stock',['added_by'=>$user_id]);
	}
	
        return $query;
    }


//searching List	
	public function search_stock_list($limit, $start ,$product , $vendor , $f_date , $t_date){
		
		$user_info = $this->session->userdata('logged_user');
        $user_id = $user_info['user_id'];
		$rolename      = singleDbTableRow($user_id)->rolename;
		$email   = singleDbTableRow($user_id)->email;
		
		$condition="";
		if($product !='')
		{
			$condition.="product = '".$product."'";
		}
		
		if($vendor !='')
		{
			if($condition != ""){
				$condition.=" AND added_by = '".$vendor."'";
			}
			else{
				$condition.="added_by = '".$vendor."'";
			}
		}
		
		if($f_date !='' && $t_date !='')
			{
				$start_fdt = new DateTime($f_date);
				$start_from = $start_fdt->format('Y-m-d');
				
				$start_tdt = new DateTime($t_date);
				$start_to = $start_tdt->format('Y-m-d');
			}
		
		if($f_date !='' && $t_date !=''){
			if($condition != ""){
				
				$condition.=" AND DATE(FROM_UNIXTIME(datetime)) >= '".$start_from."' AND DATE(FROM_UNIXTIME(datetime)) <= '".$start_to."'";
			}
			else{
				$condition.="DATE(FROM_UNIXTIME(datetime)) >= '".$start_from."' AND DATE(FROM_UNIXTIME(datetime)) <= '".$start_to."'";
			}
		}
					
		if($condition !='')
		{
			$where_array =$condition;
		}
		
		$query = $this->db->order_by('id', 'desc')->group_by('product')->group_by('added_by')->limit($limit, $start)->where($where_array )->get('smb_stock'); 
		
        return $query;
	}
	
	 public function tax_payment_listcount(){
		
		$user_info 	 = $this->session->userdata('logged_user');
        $user_id 	 = $user_info['user_id'];
		$currentUser = singleDbTableRow($user_id)->role;
		$rolename    = singleDbTableRow($user_id)->rolename;
		$email   	 = singleDbTableRow($user_id)->email;
		
		
			$query = $this->db->count_all_results('smb_sale');
		
        return $query;
    }
		
    public function tax_payment_list($limit = 0, $start = 0)
	{		
										
				$query = $this->db->order_by('id', 'desc')->limit($limit, $start)->get('smb_sale');
		
		
		
        return $query;
    }
	
	
	public function total_sales($from_date, $end_date) 
	{
		
			$where_array= "DATE(FROM_UNIXTIME(sale_datetime)) BETWEEN '".$from_date."' AND '".$end_date."'" ;
		
		
		 
		$query = $this->db->select_sum('grand_total')->where($where_array)->get('smb_sale');
		if($query -> num_rows() > 0) 
		{
			foreach ($query->result() as $credit) 
			{
				$user_credit = $credit->grand_total;
			}
			return $user_credit;
		}
		else
		{
			return 0;
		}
	}
	
	
	
	
	public function total_tax($from_date, $end_date) 
	{
		
		$where_array= "DATE(FROM_UNIXTIME(sale_datetime)) BETWEEN '".$from_date."' AND '".$end_date."'" ;
		
		
		 
		$query = $this->db->select_sum('vat')->where($where_array)->get('smb_sale');
		if($query -> num_rows() > 0) 
		{
			foreach ($query->result() as $credit) 
			{
				$user_credit = $credit->vat;
			}
			return $user_credit;
		}
		else
		{
			return 0;
		}
	}
	
	public function pay_to_vendor($vendor, $amnt, $sale_code, $vendor_invoice_no, $tran_count){
		
		$user_info 	 = $this->session->userdata('logged_user');
        $user_id 	 = $user_info['user_id'];
		
		$pay_data = [
            'vendor_id'         	=> $vendor,
            'vendor_invoice_no'     => $vendor_invoice_no,
            'sale_code'         	=> $sale_code,
            'vendor_pay_amount'     => $amnt,
            'tran_count'         	=> $tran_count,
			'status'				=> 'paid',
            'created_at'            => time(),
            'created_by'            => $user_id,
            'modified_at'           => time(),
        ];
		
		$query = $this->db->insert('smb_vendor_payment', $pay_data);
		
		
		$tranx_remark = "For Sale Code-".$sale_code." And For Vendor Invoice No-".$vendor_invoice_no;
		
		$grand_total = $this->input->post('paybal_amount');
		//loged user details
		$payment_reciever       = singleDbTableRow($vendor)->referral_code;
		
		//get_pay_type
		$get_biz = $this->db->get_where('smb_sale',['sale_code'=>$sale_code]);
		foreach($get_biz->result() as $biz);
		$biz_id = $biz->business;
		
		$pay_type = singleDbTableRow($biz_id, 'business_groups')->pay_type;
		
		
		//payment_model
		$pay_by_referral_code 	= 	'5382610497' ;		
		$pay_to_referral_code 	= 	$payment_reciever;		
		$amount_to_pay		  	=	$amnt;			
		$pay_spec_type			=	$pay_type;			
		$transaction_remarks	=	'Vendor Payment Processed.<br>For Sale Code-'.$sale_code.' And For Vendor Invoice No-'.$vendor_invoice_no;	
		$pm_mode				=	'wallet';				
		
		
		$insert = $this->smb_payment_model->make_my_payment($pay_by_referral_code, $pay_to_referral_code, $amount_to_pay, $pay_spec_type, $transaction_remarks, $pm_mode,$tranx_remark);
		
		
		
		
		
		
		if($query && $insert){
			return true;
		}
		return false;
	}
	
	
	public function all_vendor_payments_listcount(){
        $query = $this->db->count_all_results('smb_vendor_payment');
        return $query;
    }

    public function all_vendor_payments_list($limit = 0, $start = 0){
        $query = $this->db->order_by('id', 'desc')->limit($limit, $start)->get('smb_vendor_payment');
        return $query;
    }
	
	
	public function vendor_payments_search_List($vendor){
		$query = $this->db->get_where('smb_vendor_payment', ['vendor_id'=>$vendor]);
		return $query;
	}
	
}