<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Machinaries_model extends CI_Model {

    /**
     * @return bool
     */
    public function add_machinaries() {
        //$data['referral_code'] = $this->db->get('users');
        $user_info = $this->session->userdata('logged_user');
        $user_id = $user_info['user_id'];

        $currentUser = singleDbTableRow($user_id)->role;
        $rolename = singleDbTableRow($user_id)->rolename;
        $root_id = singleDbTableRow($user_id)->referral_code;

        $data = [
            'type' => $this->input->post('type'),
            'name' => $this->input->post('name'),
            'bedin_date' => $this->input->post('bedin_date'),
            'end_date' => $this->input->post('end_date'),
            'current_status' => $this->input->post('current_status'),
            'hire_type' => $this->input->post('hire_type'),
            'vehicle_id' => $this->input->post('vehicle_id'),
            'created_by' => $user_id,
            //'modified_by'			 => $user_id,
            'created_at' => time()
                //'modified_at'			 => time()
                //'root_id'              => $getreferral
        ];

        $query = $this->db->insert('machinaries', $data);

        if ($query) {
            create_activity('Added ' . $data['name'] . 'machinaries'); //create an activity
            return true;
        }
        return false;
    }

    //transport module view

    public function machinariesListCount() {

        $query = $this->db->count_all_results('machinaries');
        return $query;
    }

    public function machinariesList($limit = 10, $start = 0) {

        $user_info = $this->session->userdata('logged_user');
        $user_id = $user_info['user_id'];
        $currentUser = singleDbTableRow($user_id)->role;

        if ($currentUser == 'admin') {
            $query = $this->db->order_by('id', 'desc')->limit($limit, $start)->get('machinaries');
            return $query;
        } else {
            $table_name = 'machinaries';
            $where_array = array('created_by' => $user_id);
            $query = $this->db->order_by('id', 'desc')->limit($limit, $start)->where($where_array)->get($table_name);
            return $query;
        }
    }

    public function edit_machinaries($id) {

        $user_info = $this->session->userdata('logged_user');
        $user_id = $user_info['user_id'];

        $data = [
            'type' => $this->input->post('type'),
            'name' => $this->input->post('name'),
            'bedin_date' => $this->input->post('bedin_date'),
            'end_date' => $this->input->post('end_date'),
            'current_status' => $this->input->post('current_status'),
            'hire_type' => $this->input->post('hire_type'),
            'vehicle_id' => $this->input->post('vehicle_id'),
            'modified_by' => $user_id,
            'modified_at' => time()
        ];

        $query = $this->db->where('id', $id)->update('machinaries', $data);

        if ($query) {
            create_activity('Updated ' . $data['name'] . 'machinaries'); //create an activity
            return true;
        }
        return false;
    }

}

//last brace required
	